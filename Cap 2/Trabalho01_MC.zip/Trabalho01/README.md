# <center> Trabalho 1 - Matemática Computacional

## Equipe: 
* João Almir da Costa Junior - 470034 
* Henricky de lima monteiro - 475075


## Como rodar:

O trabalho está no arquivo `trabalho.ipynb` que pode ser lido via VSCode pela extenção *Jupyter*, o pacote `jupyter-notebook` do python, pelo próprio github ou através do Google colab, mas devem haver outras formas de ler o arquivo. Ele comporta markdown junto de células que rodam de forma independente códigos em python, que formam um documemnto interativo. 

Para que tudo funcione normalmente faz-se necessário ter o python instalado e provavelmente o pacote ikernel, porém tudo roda muito bem tendo instalado o [anaconda](https://www.anaconda.com/products/distribution).